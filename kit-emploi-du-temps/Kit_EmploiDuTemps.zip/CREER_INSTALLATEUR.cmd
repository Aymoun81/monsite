@echo off
setlocal EnableExtensions DisableDelayedExpansion
title Creer l'installateur Emploi du Temps 2020 v3

cd /d "%~dp0" || goto DossierErreur
set "APPDIR=C:\Program Files\EmploiDuTemps2020v3"
set "KITDIR=%~dp0"
set "ISCC="
if /I "%KITDIR:~0,37%"=="%APPDIR%\" goto KitDansSource
if not exist "%APPDIR%\EmploiGen.exe" goto SourceIntrouvable
if not exist "%~dp0EmploiDuTemps.iss" goto KitIncomplet
if not exist "%~dp0AVERTISSEMENT_AVEC_BASES.txt" goto KitIncomplet
if not exist "%~dp0AVERTISSEMENT_SANS_BASES.txt" goto KitIncomplet

for %%P in ("%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 6\ISCC.exe" "%LocalAppData%\Programs\Inno Setup 6\ISCC.exe" "%ProgramFiles%\Inno Setup 7\ISCC.exe" "%ProgramFiles(x86)%\Inno Setup 7\ISCC.exe" "%LocalAppData%\Programs\Inno Setup 7\ISCC.exe") do if not defined ISCC if exist "%%~P" set "ISCC=%%~P"
if not defined ISCC for /f "delims=" %%P in ('where ISCC.exe 2^>nul') do if not defined ISCC set "ISCC=%%P"
if not defined ISCC goto InnoIntrouvable

for %%P in (EmploiGen.exe EmploiSaisi.exe) do (
    tasklist /FI "IMAGENAME eq %%P" /NH 2>nul | find /I "%%P" >nul
    if not errorlevel 1 (
        echo.
        echo Fermez %%P puis relancez ce programme.
        echo Sauvegardez aussi les donnees avant de creer une copie.
        pause
        exit /b 1
    )
)

cls
echo ================================================================
echo  CREATION D'UN INSTALLATEUR DE COPIE - VERSION DE TEST
echo ================================================================
echo.
echo Fermez tous les programmes utilisant les bases, puis sauvegardez
echo vos donnees avant de continuer. Aucun fichier du PC source ne sera
echo modifie par la creation de l'installateur.
echo.
echo Ce kit ne reconstitue pas automatiquement les services, le registre
echo ni les composants externes. Le fonctionnement n'est pas garanti.
echo Les fichiers et dossiers masques ne seront en general PAS inclus.
echo.
dir /a:h /b /s "%APPDIR%" 2>nul | findstr /R "." >nul
if not errorlevel 1 goto MasquesDetectes
goto ChoixBases

:MasquesDetectes
echo ATTENTION : des fichiers ou dossiers masques ont ete detectes.
echo Ils ne seront pas inclus, sauf EmploiGen.exe et EmploiSaisi.exe.
echo Ils peuvent etre necessaires au logiciel ou contenir vos donnees.
echo En cas de doute, annulez et demandez conseil avant de continuer.
echo.
choice /C AC /N /M "A = annuler, C = creer quand meme : "
if errorlevel 2 goto ChoixBases
goto Annuler

:ChoixBases
echo Choisissez ce que contiendra le fichier EXE genere :
echo.
echo 1 - Inclure les bases MDB non masquees du dossier du programme.
echo     Elles peuvent contenir des donnees personnelles et sensibles.
echo     Les donnees stockees ailleurs ne seront PAS incluses.
echo.
echo 2 - Exclure toutes les bases MDB du dossier du programme.
echo     Certaines peuvent etre indispensables au demarrage du logiciel.
echo     D'autres fichiers peuvent aussi contenir des donnees sensibles.
echo.
echo 3 - Annuler.
echo.
choice /C 123 /N /M "Votre choix [1, 2 ou 3] : "
if errorlevel 3 goto Annuler
if errorlevel 2 goto SansBases
if errorlevel 1 goto AvecBases
goto Annuler

:AvecBases
set "MODE=/DINCLURE_MDB"
set "VARIANTE=avec_bases_MDB"
if exist "%LOCALAPPDATA%\VirtualStore\Program Files\EmploiDuTemps2020v3\" goto VirtualStore
goto Compiler

:SansBases
set "MODE=/DSANS_MDB"
set "VARIANTE=sans_bases_MDB"
goto Compiler

:VirtualStore
echo.
echo ATTENTION : un dossier VirtualStore de cette application existe
echo pour votre compte Windows. Il peut contenir des donnees recentes.
echo Son contenu ne sera PAS inclus dans l'installateur.
echo Sauvegardez-le separement et demandez conseil en cas de doute.
echo.
choice /C AC /N /M "A = annuler, C = creer quand meme : "
if errorlevel 2 goto Compiler
goto Annuler

:Compiler
set "FICHIER=Installateur_EmploiDuTemps2020v3_%VARIANTE%.exe"
if exist "%~dp0Sortie\%FICHIER%" goto DejaPresent
if not exist "%~dp0Sortie\" mkdir "%~dp0Sortie" 2>nul
if not exist "%~dp0Sortie\" goto SortieErreur
echo.
echo Compilation en cours. Cela peut prendre plusieurs minutes...
echo.
"%ISCC%" %MODE% "%~dp0EmploiDuTemps.iss"
if errorlevel 1 goto CompilationErreur
if not exist "%~dp0Sortie\%FICHIER%" goto CompilationErreur

echo.
echo ================================================================
echo Creation terminee :
echo "%~dp0Sortie\%FICHIER%"
echo.
echo Cette copie n'a pas ete validee sur l'autre PC.
echo Conservez une sauvegarde et testez sur un dossier vide.
echo ================================================================
echo.
start "" "%~dp0Sortie"
pause
exit /b 0

:SourceIntrouvable
echo.
echo ERREUR : EmploiGen.exe est introuvable dans :
echo %APPDIR%
echo Lancez ce kit sur le PC ou cette application est installee.
pause
exit /b 1

:KitIncomplet
echo.
echo ERREUR : il manque des fichiers du kit. Extrayez toute l'archive ZIP.
pause
exit /b 1

:InnoIntrouvable
echo.
echo ERREUR : le compilateur Inno Setup est introuvable.
echo Installez Inno Setup 6.3 ou plus recent, ou Inno Setup 7, depuis :
echo https://jrsoftware.org/isdl.php
echo Gardez le dossier propose pendant l'installation, puis relancez ce fichier.
pause
exit /b 1

:DossierErreur
echo.
echo ERREUR : impossible d'ouvrir le dossier du kit.
echo Extrayez le ZIP dans un dossier local, par exemple sur le Bureau.
pause
exit /b 1

:KitDansSource
echo.
echo ERREUR : le kit ne doit pas etre place dans le dossier de l'application.
echo Extrayez le ZIP ailleurs, par exemple sur le Bureau, puis recommencez.
pause
exit /b 1

:SortieErreur
echo.
echo ERREUR : impossible de creer le dossier Sortie a cote du kit.
echo Extrayez le ZIP dans un dossier local accessible en ecriture.
pause
exit /b 1

:DejaPresent
echo.
echo Un installateur de ce nom existe deja dans le dossier Sortie.
echo Pour ne pas l'ecraser, deplacez-le ou renommez-le puis recommencez.
pause
exit /b 1

:CompilationErreur
echo.
echo ERREUR : la compilation n'a pas abouti.
echo Prenez une capture du message d'erreur affiche au-dessus.
pause
exit /b 1

:Annuler
echo.
echo Operation annulee. Aucun installateur n'a ete cree.
pause
exit /b 0
