; Generateur de copie non officiel pour l'application locale.
; A utiliser depuis CREER_INSTALLATEUR.cmd, qui impose un choix explicite
; concernant les bases .mdb avant la compilation.

#define AppSource "C:\Program Files\EmploiDuTemps2020v3"

#if Pos(LowerCase(AddBackslash(AppSource)), LowerCase(AddBackslash(SourcePath))) == 1
  #error "Extrayez ce kit hors du dossier de l'application, par exemple sur le Bureau."
#endif

#ifnexist AppSource + "\EmploiGen.exe"
  #error "EmploiGen.exe introuvable dans C:\Program Files\EmploiDuTemps2020v3."
#endif

#ifdef INCLURE_MDB
  #ifdef SANS_MDB
    #error "Choix contradictoire pour les bases MDB."
  #endif
  #define Variante "avec_bases_MDB"
  #define Avertissement "AVERTISSEMENT_AVEC_BASES.txt"
#else
  #ifndef SANS_MDB
    #error "Lancez CREER_INSTALLATEUR.cmd pour choisir si les bases MDB doivent etre incluses."
  #endif
  #define Variante "sans_bases_MDB"
  #define Avertissement "AVERTISSEMENT_SANS_BASES.txt"
#endif

[Setup]
; Identifiant propre a cette copie, different de celui du logiciel d'origine.
AppId={{35D9D300-5AA7-4023-9D4C-8AEAE801E57D}
AppName=Emploi du Temps 2020 v3 - copie
; Version de ce projet d'installation, pas version connue du logiciel.
AppVersion=1.0
AppVerName=Emploi du Temps 2020 v3 - copie non officielle
DefaultDirName={autopf}\EmploiDuTemps2020v3
DefaultGroupName=Emploi du Temps 2020 v3 - copie
DisableDirPage=no
UsePreviousAppDir=no
UsePreviousGroup=no
ArchitecturesInstallIn64BitMode=x64compatible
PrivilegesRequired=admin
OutputDir=Sortie
OutputBaseFilename=Installateur_EmploiDuTemps2020v3_{#Variante}
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\EmploiGen.exe
InfoBeforeFile={#Avertissement}

[Languages]
Name: "french"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
; Les executables connus sont cites explicitement meme s'ils sont masques.
; Par prudence tous les fichiers installes sont conserves apres desinstallation.
Source: "{#AppSource}\EmploiGen.exe"; DestDir: "{app}"; Flags: ignoreversion onlyifdoesntexist uninsneveruninstall
#ifexist AppSource + "\EmploiSaisi.exe"
Source: "{#AppSource}\EmploiSaisi.exe"; DestDir: "{app}"; Flags: ignoreversion onlyifdoesntexist uninsneveruninstall
#endif
; Inno Setup ignore les autres fichiers et dossiers masques avec des jokers.
; Ne pas recopier le desinstalleur d'origine, les MDB dans cette regle,
; ou les fichiers de verrouillage Access.
Source: "{#AppSource}\*"; DestDir: "{app}"; Excludes: "EmploiGen.exe,EmploiSaisi.exe,unins*.exe,unins*.dat,unins*.msg,*.mdb,*.ldb,*.laccdb"; Flags: ignoreversion recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall
#ifdef INCLURE_MDB
; Seules les bases non masquees sont incluses apres un choix explicite.
Source: "{#AppSource}\*.mdb"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs onlyifdoesntexist uninsneveruninstall
#endif

[Icons]
Name: "{group}\Emploi du Temps - Generateur"; Filename: "{app}\EmploiGen.exe"; WorkingDir: "{app}"
#ifexist AppSource + "\EmploiSaisi.exe"
Name: "{group}\Emploi du Temps - Saisie"; Filename: "{app}\EmploiSaisi.exe"; WorkingDir: "{app}"
#endif
Name: "{autodesktop}\Emploi du Temps - Generateur"; Filename: "{app}\EmploiGen.exe"; WorkingDir: "{app}"; Tasks: desktopicon

; Aucune importation de .reg, execution de .cmd, enregistrement d'OCX ou
; installation automatique de dependance n'est effectuee. Il faut les verifier.

[Code]
function DirectoryHasItems(const Dir: String): Boolean;
var
  Rec: TFindRec;
begin
  Result := False;
  if FindFirst(AddBackslash(Dir) + '*', Rec) then
  begin
    try
      repeat
        if (Rec.Name <> '.') and (Rec.Name <> '..') then
        begin
          Result := True;
          Break;
        end;
      until not FindNext(Rec);
    finally
      FindClose(Rec);
    end;
  end;
end;

function NextButtonClick(CurPageID: Integer): Boolean;
begin
  Result := True;
  if CurPageID = wpSelectDir then
  begin
    if DirectoryHasItems(WizardDirValue) then
    begin
      MsgBox('Le dossier choisi contient deja des fichiers. Choisissez un dossier vide pour eviter d''ecraser une installation ou des donnees existantes.', mbError, MB_OK);
      Result := False;
    end;
  end;
end;

function PrepareToInstall(var NeedsRestart: Boolean): String;
begin
  Result := '';
  { Verifie aussi les installations lancees sans assistant graphique. }
  if DirectoryHasItems(ExpandConstant('{app}')) then
    Result := 'Le dossier choisi contient deja des fichiers. Choisissez un dossier vide pour eviter d''ecraser une installation ou des donnees existantes.';
end;
